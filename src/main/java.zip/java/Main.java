import View.Main.MainFrame;

public class Main {
    public static void main(String[] args) {
        MainFrame.mainFrame = new MainFrame();
        MainFrame.mainFrame.setVisible(true);
    }
}