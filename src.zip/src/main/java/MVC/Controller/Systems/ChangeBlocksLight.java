package MVC.Controller.Systems;

import MVC.Model.GameEntities.BlockSystem;
import Storage.Facade.StorageFacade;
import MVC.View.Render.GameShapes.System.GameShape;

import java.awt.*;
import java.util.List;

public class ChangeBlocksLight {
    public static void changeBlocksLight (List<GameShape> blockShapes) {
        List<BlockSystem> blockSystems = StorageFacade.loadBlockSystems();
        for (int i = 0; i < blockSystems.size(); i++){
            boolean allConnected = true;
            for (int j = 1; j <= 4; j++) {
                if (!blockSystems.get(i).getPort(j).isConnected()) {
                    allConnected = false;
                    break;
                }
            }
            blockShapes.get(i).setColor(allConnected ? Color.CYAN : Color.RED);
        }
        StorageFacade.saveBlockSystems(blockSystems);
    }
}
