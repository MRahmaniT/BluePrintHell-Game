package MVC.Controller.Levels;

import MVC.Model.Enums.BlockSystemType;
import MVC.Model.Enums.PortRole;
import MVC.Model.Enums.PortType;
import MVC.Model.GameEntities.BlockSystem;
import MVC.Model.GameEntities.Port;
import Storage.Facade.StorageFacade;
import MVC.View.Render.GameShapes.System.EndSystem;
import MVC.View.Render.GameShapes.System.StartSystem;
import MVC.View.Render.GameShapes.System.TwoStairsSystem;
import MVC.View.Render.GameShapes.System.GameShape;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BuildLevel2 {
    public static void buildLevel2(int screenSizeX, List<GameShape> blockShapes){

        List<BlockSystem> blockSystems = StorageFacade.loadBlockSystems();
        BlockSystem blockSystem;
        GameShape block;
        Port port1,port2,port3,port4;
        ArrayList<Port> ports;
        int blockSystemId = blockSystems.size();

        //Block Start
        port1 = new Port(1, blockSystemId);
        port2 = new Port(2, blockSystemId);
        port3 = new Port(3, blockSystemId, PortRole.OUT, PortType.MESSENGER_3);
        port4 = new Port(4, blockSystemId);
        ports = new ArrayList<>(Arrays.asList(port1, port2, port3, port4));

        blockSystem = new BlockSystem(blockSystemId, BlockSystemType.START, ports, -300, -100);
        blockSystems.add(blockSystem);

        block = new StartSystem(blockSystem,0.1f * screenSizeX, 0.1f * screenSizeX);
        blockShapes.add(block);

        blockSystemId++;

        //Block 1
        port1 = new Port(1, blockSystemId);
        port2 = new Port(2, blockSystemId, PortRole.IN, PortType.MESSENGER_3);
        port3 = new Port(3, blockSystemId, PortRole.OUT, PortType.MESSENGER_3);
        port4 = new Port(4, blockSystemId, PortRole.OUT, PortType.MESSENGER_2);
        ports = new ArrayList<>(Arrays.asList(port1, port2, port3, port4));

        blockSystem = new BlockSystem(blockSystemId, BlockSystemType.PROCESSOR, ports, -100, -100);
        blockSystems.add(blockSystem);

        block = new TwoStairsSystem(blockSystem,0.1f * screenSizeX, 0.1f * screenSizeX);
        blockShapes.add(block);

        blockSystemId++;

        //Block 2
        port1 = new Port(1, blockSystemId, PortRole.IN, PortType.MESSENGER_3);
        port2 = new Port(2, blockSystemId, PortRole.IN, PortType.MESSENGER_2);
        port3 = new Port(3, blockSystemId, PortRole.OUT, PortType.MESSENGER_3);
        port4 = new Port(4, blockSystemId);
        ports = new ArrayList<>(Arrays.asList(port1, port2, port3, port4));

        blockSystem = new BlockSystem(blockSystemId, BlockSystemType.PROCESSOR, ports, 100, 100);
        blockSystems.add(blockSystem);

        block = new TwoStairsSystem(blockSystem,0.1f * screenSizeX, 0.1f * screenSizeX);
        blockShapes.add(block);

        blockSystemId++;

        //Block End
        port1 = new Port(1, blockSystemId, PortRole.IN, PortType.MESSENGER_3);
        port2 = new Port(2, blockSystemId);
        port3 = new Port(3, blockSystemId);
        port4 = new Port(4, blockSystemId);
        ports = new ArrayList<>(Arrays.asList(port1, port2, port3, port4));

        blockSystem = new BlockSystem(blockSystemId, BlockSystemType.START, ports, 300, 100);
        blockSystems.add(blockSystem);

        block = new EndSystem(blockSystem,0.1f * screenSizeX, 0.1f * screenSizeX);
        blockShapes.add(block);



        StorageFacade.saveBlockSystems(blockSystems);
    }
}
