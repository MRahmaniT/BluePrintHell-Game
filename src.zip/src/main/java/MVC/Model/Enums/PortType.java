package MVC.Model.Enums;

import java.io.Serializable;

public enum PortType implements Serializable {
    MESSENGER_1, MESSENGER_2, MESSENGER_3
}
