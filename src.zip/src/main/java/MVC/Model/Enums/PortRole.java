package MVC.Model.Enums;

import java.io.Serializable;

public enum PortRole implements Serializable { IN, OUT }
