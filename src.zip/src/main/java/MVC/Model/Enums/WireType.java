package MVC.Model.Enums;

import java.io.Serializable;

public enum WireType implements Serializable {
    STRAIGHT,
    CURVE1,
    CURVE2,
    CURVE3
}
