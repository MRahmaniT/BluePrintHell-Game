import MVC.Controller.GameLogic;
import MVC.View.Main.MainFrame;
import Modes.InputSink;

public class Main {
    public static void main(String[] args) {
        MainFrame.mainFrame = new MainFrame();
        MainFrame.mainFrame.setVisible(true);
    }
}