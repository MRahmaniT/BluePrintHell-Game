package Client.Storage.RealTime;

public final class StorageLocks {
    private StorageLocks() {}
    public static final Object IOLock = new Object();
}
