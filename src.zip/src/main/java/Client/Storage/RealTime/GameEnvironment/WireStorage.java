package Client.Storage.RealTime.GameEnvironment;

import Client.Model.GameEntities.Wire.Wire;
import Client.Storage.RealTime.StorageLocks;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WireStorage {
    private static final String WIRES_FILE = "Resources/Saves/Realtime/wire.json";

    public static List<Wire> LoadWires() {
        synchronized (StorageLocks.IOLock) {
            ObjectMapper objectMapper = new ObjectMapper();
            File file = new File(WIRES_FILE);

            if (!file.exists()) return new ArrayList<>();

            try {
                return objectMapper.readValue(file, new TypeReference<List<Wire>>() {
                });
            } catch (IOException e) {
                e.printStackTrace();
                return new ArrayList<>();
            }
        }
    }

    public static void SaveWires(List<Wire> wires) {
        synchronized (StorageLocks.IOLock) {
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                objectMapper.writerWithDefaultPrettyPrinter().writeValue(new File(WIRES_FILE), wires);
                //System.out.println("All Wires saved.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
